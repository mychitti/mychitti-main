@extends('front-views.layout')

@section('title', $catDetails->name)

@section('seo')
<meta content="3" name="keywords">
<meta content="32" name="description">
@endsection

@push('css_or_js')
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <style>
    .pagination{
        display: flex;
    }
    .pagination span{
        padding: 10px 16px;
    }
  </style>
@endpush

@section('content')
       <!-- Single Page Header start -->
       <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">{{$catDetails->name}}</h1>
            <ol class="breadcrumb justify-content-center mb-0"> 
                <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                <li class="breadcrumb-item active text-white">{{$catDetails->name}}</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Fruits Shop Start-->
        <div class="container-fluid fruite py-5">
            <div class="container py-5">
                <h1 class="mb-4">{{$catDetails->name}}</h1>
                <div class="row g-4">
                    <div class="col-lg-12">
                        <div class="row g-4">
                            <div class="col-xl-3">
                                <div class="input-group w-100 mx-auto d-flex">
                                    <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                                    <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                                </div>
                            </div>
                            <div class="col-6"></div>
                            <!-- <div class="col-xl-3">
                                <div class="bg-light ps-3 py-3 rounded d-flex justify-content-between mb-4">
                                    <label for="fruits">Default Sorting:</label>
                                    <select id="fruits" name="fruitlist" class="border-0 form-select-sm bg-light me-3" form="fruitform">
                                        <option value="volvo">Nothing</option>
                                        <option value="saab">Popularity</option>
                                        <option value="opel">Organic</option>
                                        <option value="audi">Fantastic</option>
                                    </select>
                                </div>
                            </div> -->
                        </div>
                        <div class="row g-4">
                            <div class="col-lg-3">
                                <div class="row g-4">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <h4>Categories</h4>
                                            <ul class="list-unstyled fruite-categorie">
                                                @foreach($data['all_categories'] as $ct)
                                                <li>
                                                    <div class="d-flex justify-content-between fruite-name">
                                                        <a href="{{$ct['slug']}}"><img class="rounded border" style="height:40px; width:40px; object-fit:cover;" data-onerror-image="{{asset('public/assets/admin/img/160x160/img1.jpg')}}"
                                                        src="{{\App\CentralLogics\Helpers::onerror_image_helper($ct['image'], asset('storage/app/public/category/').'/'.$ct['image'], asset('public/assets/admin/img/160x160/img1.jpg'), 'category/') }}"> &nbsp; &nbsp;{{$ct['name']}}</a>
                                                        <span>({{$ct['product_count']}})</span>
                                                    </div>
                                                </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- <div class="col-lg-12">
                                        <div class="mb-3">
                                            <h4 class="mb-2">Price</h4>
                                            <input type="range" class="form-range w-100" id="rangeInput" name="rangeInput" min="0" max="500" value="0" oninput="amount.value=rangeInput.value">
                                            <output id="amount" name="amount" min-velue="0" max-value="500" for="rangeInput">0</output>
                                        </div>
                                    </div> -->
                                    <!-- <div class="col-lg-12">
                                        <div class="mb-3">
                                            <h4>Additional</h4>
                                            <div class="mb-2">
                                                <input type="radio" class="me-2" id="Categories-1" name="Categories-1" value="Beverages">
                                                <label for="Categories-1"> Organic</label>
                                            </div>
                                            <div class="mb-2">
                                                <input type="radio" class="me-2" id="Categories-2" name="Categories-1" value="Beverages">
                                                <label for="Categories-2"> Fresh</label>
                                            </div>
                                            <div class="mb-2">
                                                <input type="radio" class="me-2" id="Categories-3" name="Categories-1" value="Beverages">
                                                <label for="Categories-3"> Sales</label>
                                            </div>
                                            <div class="mb-2">
                                                <input type="radio" class="me-2" id="Categories-4" name="Categories-1" value="Beverages">
                                                <label for="Categories-4"> Discount</label>
                                            </div>
                                            <div class="mb-2">
                                                <input type="radio" class="me-2" id="Categories-5" name="Categories-1" value="Beverages">
                                                <label for="Categories-5"> Expired</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-lg-12">
                                    <h4 class="mb-4">Featured products</h4>
                                        @foreach($data['featured_products'] as $fPro)
                                        <div class="d-flex align-items-center justify-content-start my-1"> 
                                            <div class="rounded border mx-2" style="width: 100px; height: 100px;" > 
                                                <img style="height:100%; width: 100% ; object-fit:cover;" src="{{asset('storage/app/public/product/').'/'.$fPro->image}}" class="img-fluid rounded" alt="Image">
                                            </div>
                                            <div>  
                                                <h6 class="mb-2"><a href="{{route('product.details', [$fPro->slug])}}">{{ucfirst($fPro->name)}}</a></h6>
                                                <div class="d-flex mb-2">
                                                @for($i = 1; $i < 6; $i++)
                                                    @if($fPro->avg_rating >= $i)
                                                    <i class="fa fa-star text-secondary"></i>
                                                    @else
                                                    <i class="fa fa-star"></i>  
                                                    @endif
                                                @endfor
                                                </div>
                                                <div class="d-flex mb-2">
                                                    <h5 class="fw-bold me-2">{{\App\CentralLogics\Helpers::currency_symbol() . $fPro->price}}</h5>
                                                    <!-- <h5 class="text-danger text-decoration-line-through">4.11 $</h5> -->
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                
                                    </div>
                                    <!-- <div class="col-lg-12">
                                        <div class="position-relative">
                                            <img src="{{asset('public/assets/front/img/banner-fruits.jpg')}}" class="img-fluid w-100 rounded" alt="">
                                            <div class="position-absolute" style="top: 50%; right: 10px; transform: translateY(-50%);">
                                                <h3 class="text-secondary fw-bold">Fresh <br> Fruits <br> Banner</h3>
                                            </div>
                                        </div>
                                    </div> --> 
                                </div>
                            </div>
                            <div class="col-lg-9">
                                <div class="row g-4 justify-content-center">

                                @foreach($catProducts as $pro)
                                    <div class="col-md-6 col-lg-6 col-xl-4">
                                        <div class="rounded position-relative fruite-item">
                                            <div class="fruite-img"  style="height: 290px !important;  border: 1px solid #ffb524;  border-bottom: 0px;">
                                                <img style="height: 290px !important;object-fit:cover" data-onerror-image="{{asset('public/assets/admin/img/160x160/img1.jpg')}}"
                                                src="{{\App\CentralLogics\Helpers::onerror_image_helper($pro['image'], asset('storage/app/public/product/').'/'.$pro['image'], asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}" class="img-fluid w-100 rounded-top" alt="">
                                            </div>
                                            <div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;">{{$pro->discount_type == 'percent' ? '' :  \App\CentralLogics\Helpers::currency_symbol() }}{{$pro->discount}}{{$pro->discount_type == 'percent' ? '%' : ''}} OFF</div>
                                            <div class="p-4 border border-secondary border-top-0 rounded-bottom">
                                                <h4><a href="{{route('product.details', [$pro['slug']])}}">{{$pro['name']}}</a></h4>
                                                <p>{{substr(ucfirst($pro['description']), 0, 100)}}...</p>
                                                <div class="d-flex justify-content-between flex-lg-wrap"> 
                                                    <p class="text-dark fs-5 fw-bold mb-0">{{\App\CentralLogics\Helpers::currency_symbol() . $pro['price']}}</p>
                                                    <a href="#" class="btn border border-secondary rounded-pill px-3 text-primary"><i class="fa fa-shopping-bag me-2 text-primary"></i> Add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                @if(!count($catProducts))
                                <img style="width: 400px;" src="{{asset('public/assets/front/img/sorry-item-not-found-3328225-2809510.webp')}}" alt="">
                                <h4 style="text-align: center;">Oops! No products found</h4>
                                @endif
 
                                <div class='d-flex'>
                                    {{ $catProducts->links() }}
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Fruits Shop End-->


@endsection

@push('script_2')

@endpush