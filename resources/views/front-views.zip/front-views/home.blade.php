@extends('front-views.layout')

@section('title', 'Home')

@push('css_or_js')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')



    <!-- Hero Start -->
    <div class="container-fluid py-5 mb-5 hero-header">
        <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-md-12 col-lg-7">
                    <h4 class="mb-3 text-secondary">Best Products</h4>
                    <h1 class="mb-5 display-3 text-primary">Trending Product To Buy</h1>
                    <div class="position-relative mx-auto">
                        <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill" type="number"
                            placeholder="Search">
                        <button type="submit"
                            class="btn btn-primary border-2 border-secondary py-3 px-4 position-absolute rounded-pill text-white h-100"
                            style="top: 0; right: 25%;">Submit Now</button>
                    </div>
                </div>
                <div class="col-md-12 col-lg-5">
                    <div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            @foreach ($data['h_categories'] as $key => $ct)
                                <div class="carousel-item {{ !$key ? 'active' : '' }} rounded">
                                    <img style="height: 400px !important; object-fit: cover;"
                                        data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}"
                                        src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct['image'], asset('storage/app/public/category/') . '/' . $ct['image'], asset('public/assets/admin/img/160x160/img1.jpg'), 'category/') }}"
                                        class="img-fluid w-100 h-100 bg-secondary rounded" alt="First slide">
                                    <a href="{{ route('category.listing', [$ct['slug']]) }}"
                                        class="btn px-4 py-2 text-white rounded">{{ $ct['name'] }}</a>
                                </div>
                            @endforeach

                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselId"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselId"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->


    <!-- Bestsaler Product Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="text-center mx-auto mb-5" style="max-width: 700px;">
                <h1 class="display-4">Featured Stores</h1>
                <!--<p>Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.</p>-->
            </div>
            <div class="row g-4">
                <style>

                </style>

                @foreach ($stores['featued_stores'] as $key => $store)
                    <div class="col-lg-6 col-xl-4">
                        <!--'https://dev4.w4u.us/mychitty_new/storage/app/public/store/2024-05-24-66516c59a79bc.png'-->
                        <div class="p-4 rounded bg-light store-card{{ $key }} position-relative">
                            <style>
                                .store-card {
                                        {
                                        $key
                                    }
                                }

                                ::before {
                                    background: url('{{ asset(' storage/app/public/store/cover/') . ' /' . $store->cover_photo }}');
                                }
                            </style>
                            <div class="row align-items-center">
                                <div class="col-6">
                                    <img style="height: 185px;
    width: 185px !important;"
                                        data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}"
                                        src="{{ \App\CentralLogics\Helpers::onerror_image_helper($store->logo, asset('storage/app/public/store/') . '/' . $store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}"
                                        class="img-fluid rounded-circle w-100" alt="">
                                </div>
                                <div class="col-6">
                                    <a href="{{ route('store.details', [$store->slug]) }}"
                                        class="h5">{{ $store->name }}</a>
                                    <div class="d-flex my-3">
                                        @for ($i = 0; $i < 5; $i++)
                                            @if ($store->avg_rating > $i)
                                                <i class="fas fa-star text-primary"></i>
                                            @else
                                                <i class="fas fa-star"></i>
                                            @endif
                                        @endfor

                                        @if ($store->rating_count != '')
                                            ({{ $store->rating_count }})
                                        @endif
                                    </div>
                                    <!--<h4 class="mb-3">3.12 $</h4>-->
                                    <p style="min-height: 58px;">{{ $store->address }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                <div class="col-lg-6 col-xl-4">
                    <div class="p-4 rounded bg-light h-100">
                        <div class="row align-items-center h-100">

                            <div class="col-12 d-flex align-items-center justify-content-center">
                                <a href="#" class="h5">View All</a>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Bestsaler Product End -->



    <!-- Featurs Section Start -->
    <div class="container-fluid featurs py-5">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="featurs-item text-center rounded bg-light p-4">
                        <div class="featurs-icon btn-square rounded-circle bg-secondary mb-5 mx-auto">
                            <i class="fas fa-car-side fa-3x text-white"></i>
                        </div>
                        <div class="featurs-content text-center">
                            <h5>Free Shipping</h5>
                            <p class="mb-0">Free on order over $300</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="featurs-item text-center rounded bg-light p-4">
                        <div class="featurs-icon btn-square rounded-circle bg-secondary mb-5 mx-auto">
                            <i class="fas fa-user-shield fa-3x text-white"></i>
                        </div>
                        <div class="featurs-content text-center">
                            <h5>Security Payment</h5>
                            <p class="mb-0">100% security payment</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="featurs-item text-center rounded bg-light p-4">
                        <div class="featurs-icon btn-square rounded-circle bg-secondary mb-5 mx-auto">
                            <i class="fas fa-exchange-alt fa-3x text-white"></i>
                        </div>
                        <div class="featurs-content text-center">
                            <h5>30 Day Return</h5>
                            <p class="mb-0">30 day money guarantee</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="featurs-item text-center rounded bg-light p-4">
                        <div class="featurs-icon btn-square rounded-circle bg-secondary mb-5 mx-auto">
                            <i class="fa fa-phone-alt fa-3x text-white"></i>
                        </div>
                        <div class="featurs-content text-center">
                            <h5>24/7 Support</h5>
                            <p class="mb-0">Support every time fast</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Featurs Section End -->


    <!-- Fruits Shop Start-->
    <div class="container-fluid fruite py-5" id="products">
        <div class="container py-5">
            <div class="tab-class text-center">
                <div class="row g-4">
                    <div class="col-lg-4 text-start">
                        <h1>Featured Products</h1>
                    </div>
                    <div class="col-lg-8 text-end">
                        <ul class="nav nav-pills d-inline-flex text-center mb-5">
                            <!-- <li class="nav-item">
                                        <a class="d-flex m-2 py-2 bg-light rounded-pill active" data-bs-toggle="pill" href="#tab--1">
                                            <span class="text-dark" style="width: 130px;">All Products</span>
                                        </a>
                                    </li> -->
                            @foreach ($data['cats'] as $key => $cat)
                                @if ($cat['products_count'])
                                    <li class="nav-item">
                                        <a class="d-flex py-2 m-2 bg-light rounded-pill {{ !$key ? 'active' : '' }}"
                                            data-bs-toggle="pill" href="#tab-{{ $key }}">
                                            <span class="text-dark"
                                                style="width: fit-content; padding: 0px 10px;">{{ $cat['name'] }}</span>
                                        </a>
                                    </li>
                                @endif
                            @endforeach

                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    @foreach ($data['cats'] as $key => $cat)
                        <div id="tab-{{ $key }}" class="tab-pane fade show p-0 {{ !$key ? 'active' : '' }}">
                            <div class="row g-4">
                                <div class="col-lg-12">
                                    <div class="row g-4">
                                        @php $ftrdPro = _getProductsByCat($cat['id'])  @endphp
                                        @foreach ($ftrdPro as $pro)
                                        @php
                                            $variations = json_decode($pro['variations']);
                                        @endphp
                                    
                                            <div class="col-md-6 col-lg-4 col-xl-3">
                                                <div class="rounded position-relative fruite-item">
                                                    <div class="fruite-img"
                                                        style="height: 290px !important;  border: 1px solid #ffb524;  border-bottom: 0px;">
                                                        <img style="height: 290px !important;object-fit:cover"
                                                            data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}"
                                                            src="{{ \App\CentralLogics\Helpers::onerror_image_helper($pro['image'], asset('storage/app/public/product/') . '/' . $pro['image'], asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}"
                                                            class="img-fluid w-100 rounded-top" alt=""> 
                                                    </div>  
                                                    <div onclick="wishlist({{$pro['id']}}, '{{_itemExistInWishlist($pro['id']) ? 'remove': 'add'}}')" class="prHeart_{{$pro['id']}} bg-light p-2 rounded border position-absolute"
                                                        style="top: 10px; right: 10px;cursor:pointer"><i class="fa fa-heart heart_{{$pro['id']}} {{_itemExistInWishlist($pro['id']) ? 'text-danger': ''}}"></i></div>

                                                    <div class="text-white bg-secondary px-3 py-1 rounded position-absolute"
                                                        style="top: 10px; left: 10px;">{{ $cat['name'] }}</div>
                                                    <div class="p-4 border border-secondary border-top-0 rounded-bottom">
                                                        <a href="{{ route('product.details', [$pro['slug']]) }}"> 
                                                            <h4>{{ ucfirst($pro['name']) }}</h4> 
                                                            <p style="min-height:25px"> {{ !empty($variations) ? ' (' .  $variations[0]->type . ')' : ''}}</p>
                                                        </a>
                                                        <p style="height:30px;">
                                                            {{ _limitDesc($pro['description'], 64) }}</p> 
                                                        <div class="d-flex justify-content-between flex-lg-wrap">  
                                                            <div class="d-flex align-items-end">
                                                                <p class="text-dark fs-5 fw-bold mb-0 mx-1">  
                                                                {{ \App\CentralLogics\Helpers::currency_symbol()}} {{  _discountedPrice($pro['price'], $pro['discount'], $pro['discount_type'] ) }}
                                                                </p> 
                                                                @if($pro['discount'])
                                                                <p class="text-danger text-decoration-line-through mb-0">{{ \App\CentralLogics\Helpers::currency_symbol()}} {{  $pro['price'] }}</p>
                                                                @endif  
                                                            </div> 
                                                            <div class="cart-section cartSec_{{ $pro['id'] }}">
                                                             @php $firstVr = !empty($variations) ? json_encode($variations[0]) : ""  @endphp 
                                                  
                                                                @if (_itemExistInCart($pro['id'], json_encode('[' . $firstVr .']' ) ))
                                                                    <a onclick="updateCart({{ $pro['id'] }}, 'remove','{{  !empty($variations)? 1: 0 }}',  {{ _itemExistInCart( $pro['id'], json_encode('[' . $firstVr .']' )) }})"
                                                                        class="btn border border-secondary rounded-pill px-3 text-primary"><i
                                                                            class="fa fa-shopping-bag me-2 text-primary"></i>Remove</a>
                                                                @else
                                                                    <a onclick="updateCart({{ $pro['id'] }}, 'add','{{  !empty($variations)? 1: 0 }}',  '')"
                                                                        class="btn border border-secondary rounded-pill px-3 text-primary"><i
                                                                            class="fa fa-shopping-bag me-2 text-primary"></i>
                                                                        Add to cart</a>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <!-- Fruits Shop End-->


    <!-- Featurs Start -->
    <div class="container-fluid service py-5">
        <div class="container py-5">
            <div class="text-center mx-auto mb-5" style="max-width: 700px;">
                <h4 class="display-6">Special Offer</h4>
                <!--<p>Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.</p>-->
            </div>

            <div class="row g-4 justify-content-center">
                @foreach ($items['special_products'] as $key => $pro)
                    <div class="col-md-6 col-lg-3">
                        <a href="#">
                            <div
                                class="service-item {{ $key % 2 == 0 ? 'bg-secondary' : 'bg-primary' }} rounded border {{ $key % 2 == 0 ? 'border-secondary' : 'border-primary' }}">
                                <img style="height:290px;     background: white;"
                                    data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}"
                                    src="{{ \App\CentralLogics\Helpers::onerror_image_helper($pro->image, asset('storage/app/public/product/') . '/' . $pro->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}"
                                    class="img-fluid w-100 rounded-top" alt="">
                                <div class="px-4 rounded-bottom">
                                    <div
                                        class="service-content {{ $key % 2 == 0 ? 'bg-primary' : 'bg-secondary' }}  text-center p-4 rounded">
                                        <h5 class="text-white">{{ ucfirst($pro->name) }}</h5>
                                        <h3 class="mb-0">
                                            {{ $pro->discount_type == 'percent' ? '' : \App\CentralLogics\Helpers::currency_symbol() }}{{ $pro->discount }}{{ $pro->discount_type == 'percent' ? '%' : '' }}
                                            OFF</h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    <!-- Featurs End -->


    <!-- Vesitable Shop Start-->
    <div class="container-fluid vesitable py-5" id="stores">
        <div class="container py-5">
            <h1 class="mb-0">New Stores On My Chitti</h1>
            <div class="owl-carousel vegetable-carousel justify-content-center">

                @foreach ($stores['new_stores'] as $key => $store)
                    <div class="border border-primary rounded position-relative vesitable-item">
                        <div class="vesitable-img">
                            <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}"
                                src="{{ \App\CentralLogics\Helpers::onerror_image_helper($store->cover_photo, asset('storage/app/public/store/cover/') . '/' . $store->cover_photo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/cover/') }}"
                                class="img-fluid w-100 rounded-top" style="height: 180px !important; object-fit: cover;"
                                alt="">
                        </div>
                        <div class="text-white bg-primary rounded position-absolute" style="top: 10px; right: 10px; ">
                            @if ($store->logo != '')
                                <img src="{{ \App\CentralLogics\Helpers::onerror_image_helper($store->logo, asset('storage/app/public/store/') . '/' . $store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}"
                                    class="img-fluid rounded"
                                    style=" width: 65px !important; border: 4px solid #81c408;height: 65px !important;object-fit: cover;"
                                    alt="">
                            @endif
                        </div>
                        <div class="p-4 rounded-bottom">
                            <h4>{{ ucfirst($store->name) }}</h4>
                            <p>{{ $store->footer_text }}</p>
                            <div class="d-flex justify-content-between flex-lg-wrap">
                                <p class="fs-6 fw-bold mb-0"></p>
                                <a href="#" class="btn border border-secondary rounded-pill px-3 text-primary"><i
                                        class="fa fa-shopping-bag me-2 text-primary"></i> Explore </a>
                            </div>
                        </div>
                    </div>
                @endforeach

                <!-- <div class="border border-primary rounded position-relative vesitable-item">
                            <div class="vesitable-img">
                                <img src="{{ asset('public/assets/front/img/vegetable-item-1.jpg') }}" class="img-fluid w-100 rounded-top" alt="">
                            </div>
                            <div class="text-white bg-primary px-3 py-1 rounded position-absolute" style="top: 10px; right: 10px;">Vegetable</div>
                            <div class="p-4 rounded-bottom">
                                <h4>Parsely</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod te incididunt</p>
                                <div class="d-flex justify-content-between flex-lg-wrap">
                                    <p class="text-dark fs-5 fw-bold mb-0">$4.99 / kg</p>
                                    <a href="#" class="btn border border-secondary rounded-pill px-3 text-primary"><i class="fa fa-shopping-bag me-2 text-primary"></i> Add to cart</a>
                                </div>
                            </div>
                        </div> -->

            </div>
        </div>
    </div>
    <!-- Vesitable Shop End -->


    <!-- Banner Section Start-->
    <!-- <div class="container-fluid banner bg-secondary my-5">
                <div class="container py-5">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-6">
                            <div class="py-4">
                                <h1 class="display-3 text-white">Big Saving</h1>
                                <p class="fw-normal display-3 text-dark mb-4">in Our Store</p>
                                <p class="mb-4 text-dark">The generated Lorem Ipsum is therefore always free from repetition injected humour, or non-characteristic words etc.</p>
                                <a href="#" class="banner-btn btn border-2 border-white rounded-pill text-dark py-3 px-5">BUY</a>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="position-relative">
                                <img src="{{ asset('public/assets/front/img/baner-1.png') }}" class="img-fluid w-100 rounded" alt="">
                                <div class="d-flex align-items-center justify-content-center bg-white rounded-circle position-absolute" style="width: 140px; height: 140px; top: 0; left: 0;">
                                    <h1 style="font-size: 100px;">1</h1>
                                    <div class="d-flex flex-column">
                                        <span class="h2 mb-0">50$</span>
                                        <span class="h4 text-muted mb-0">piece</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
    <!-- Banner Section End -->
    <div class="owl-carousel banner-carousel justify-content-center">
        @foreach ($data['banners'] as $key => $value)
            <img src="{{ asset('storage/app/public/banner/') . '/' . $value['image'] }}"
                style="height: 700px;object-fit:cover" alt="">
        @endforeach
    </div>

    <!-- Fact Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="bg-light p-5 rounded">
                <div class="row g-4 justify-content-center">
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="counter bg-white rounded p-5">
                            <i class="fa fa-users text-secondary"></i>
                            <h4>satisfied customers</h4>
                            <h1>1963</h1>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="counter bg-white rounded p-5">
                            <i class="fa fa-users text-secondary"></i>
                            <h4>quality of service</h4>
                            <h1>99%</h1>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="counter bg-white rounded p-5">
                            <i class="fa fa-users text-secondary"></i>
                            <h4>quality certificates</h4>
                            <h1>33</h1>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="counter bg-white rounded p-5">
                            <i class="fa fa-users text-secondary"></i>
                            <h4>Available Products</h4>
                            <h1>789</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Fact Start -->


@endsection

<script>
    function updateCart(prId, action, variation, cart_id) {
        if (action == 'add') {
            var url = "{{ route('add-to-cart') }}";
        } else {
            var url = "{{ route('remove-from-cart') }}";
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.post({
            url: url,
            data: {
                prId: prId,
                cart_id: cart_id,
                variation : variation
            },
            beforeSend: function() {
                $('#loading').show()
            },
            success: function(data) {
                console.log(data.firstvr)
                if (data.status) { 
                    toasterNotification(data.message)  
                    if (action == 'add') {  
                        var cartBtn = ` <a onclick="updateCart(` + prId + `, 'remove', '', '` + data.cart_id +
                            `')" class="btn border border-secondary rounded-pill px-3 text-primary"><i class="fa fa-shopping-bag me-2 text-primary"></i>Remove</a>`
                    } else {
                        var cartBtn = ` <a onclick="updateCart(` + prId +
                            `, 'add',  '`+data.firstVr+`', '')" class="btn border border-secondary rounded-pill px-3 text-primary"><i class="fa fa-shopping-bag me-2 text-primary"></i>Add to cart</a>`

                    }
                    $(".cartSec_" + prId).html(cartBtn);
                    $('.cart-count-outer').load(window.location.href + ' .cart-count-inner')

                } else {
                    toasterNotification(data.message)
                }
            },
            complete: function() {
                $('#loading').hide()
            }
        });
    }

    function wishlist(prid, action){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.post({ 
            url: '{{route("update-wishlist")}}',
            data: {
                item_id: prid,
                store_id: '',
                action : action
            },
            beforeSend: function () { 
            },
            success: function (data) { 
                if(data.status){
                    if(action == 'add'){
                        $('.heart_'  + prid).addClass('text-danger') 
                        $('.prHeart_'  + prid).attr('onclick', 'wishlist('+prid+', "remove")');
                    }else{
                        $('.heart_'  + prid).removeClass('text-danger')
                        $('.prHeart_'  + prid).attr('onclick', 'wishlist('+prid+', "add")');
                    }
                }
                toasterNotification(data.message)
            },
            complete: function () {
            }
        });
    }

  
</script>

@push('script_2') 
@endpush
