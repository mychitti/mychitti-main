<!--<link href="{{asset('public/assets/admin/css/fonts.css')}}" rel="stylesheet">-->

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>My Chitti | @yield('title')</title>
        <meta name="csrf-token" id="csrf-token" content="{{ csrf_token() }}">
        
         @php($logo=\App\Models\BusinessSetting::where(['key'=>'icon'])->first()->value)
        <link rel="icon" type="image/x-icon" href="{{asset('storage/app/public/business/'.$logo??'')}}">
    
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
   
        <meta content="@yield('title')" name="title">
        <meta content="@yield('meta_description')" name="description">
 

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="{{asset('public/assets/front/lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">
        <link href="{{asset('public/assets/front/lib/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="{{asset('public/assets/front/css/bootstrap.min.css')}}" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="{{asset('public/assets/front/css/style.css')}}" rel="stylesheet">

    
        
        @stack('css_or_js')
        
    </head>

    <body>




   
  

@include('front-views.partials._navbar')

@yield('content')

@include('front-views.partials._footer')
<div id="toast" class="toast">This is a toaster notification!</div>

 <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{asset('public/assets/front/lib/easing/easing.min.js')}}"></script>
    <script src="{{asset('public/assets/front/lib/waypoints/waypoints.min.js')}}"></script>
    <script src="{{asset('public/assets/front/lib/lightbox/js/lightbox.min.js')}}"></script>
    <script src="{{asset('public/assets/front/lib/owlcarousel/owl.carousel.min.js')}}"></script>

    <!-- Template Javascript -->
    <script src="{{asset('public/assets/front/js/main.js')}}"></script>
    <script src="{{asset('public/assets/front/js/custom.js')}}"></script>


@stack('script')


 
@stack('script_2')

</body>
</html>
