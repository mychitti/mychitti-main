@extends('front-views.layout')

@section('title', $user_details->f_name . ' '.$user_details->l_name )

@section('seo')

@endsection

@push('css_or_js')

<meta name="csrf-token" content="{{ csrf_token() }}">

@endpush

@section('content')
<div class="spacer" style="height: 153px;"></div>

<div class="container  mt-5">
    <div class="d-flex align-items-start shadow rounded p-4">
        <div class="nav flex-column nav-pills me-3" style="width: 20%;" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <img style="width: 100px; height:100px;border-radius:50%;    margin: 10px auto;" src="{{\App\CentralLogics\Helpers::onerror_image_helper($user_details->image, asset('storage/app/public/profile/').'/'.$user_details->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'profile/') }}" alt="">
            <button class="nav-link active" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Profile</button>
            <button class="nav-link " id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Address</button>
            <button class="nav-link " id="v-pills-order-tab" data-bs-toggle="pill" data-bs-target="#v-pills-order" type="button" role="tab" aria-controls="v-pills-order" aria-selected="true">Orders</button>
            <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Favourite</button>
            <button class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalLogout">Logout</button>
        </div> 
        <div class="tab-content " id="v-pills-tabContent" style="width:100% ;min-height: 300px;">
            <div class="tab-pane fade  show active " id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                <div class="container p-5">
                    <h3 class="text-primary  my-2">Profile</h3>
                    <form class="formSubmit" action="{{route('update-profile')}}" method="post">
                        @csrf
                        <div class="row ">
                            <div class="col-md-12  row">
                                <div class="row col-lg-8">
                                    <div class="col-md-12 col-lg-12">
                                        <div class="form-item w-100">
                                            <label class="form-label my-3">First Name<sup>*</sup></label>
                                            <input type="text" name="f_name" required value="{{$user_details->f_name}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-lg-12">
                                        <div class="form-item w-100">
                                            <label class="form-label my-3">Last Name<sup>*</sup></label>
                                            <input type="text" name="l_name" required value="{{$user_details->l_name}}" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-md-12 col-lg-12">
                                        <div class="form-item w-100">
                                            <label class="form-label my-3">Email<sup>*</sup></label>
                                            <input type="text" name="email" required value="{{$user_details->email}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-lg-12">
                                        <div class="form-item w-100">
                                            <label class="form-label my-3">Mobile</label>
                                            <input disabled value="{{$user_details->phone}}" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="rounded p-2 col-lg-4 d-flex flex-column position-relative align-items-center" style="height: fit-content;">
                                    <img class="rounded" style="width: 200px; height:200px;margin-bottom:8px;" src="{{\App\CentralLogics\Helpers::onerror_image_helper($user_details->image, asset('storage/app/public/profile/').'/'.$user_details->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'profile/') }}" alt="">
                                    <input type="file" name="image" style="width: 200px;" class="form-control bg-white">
                                </div>
                                <div class="mt-4">
                                    <button type="submit" class="btn border-secondary text-primary">Update</button>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="tab-pane fade" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <div class="container p-5">
                    <h3 class="text-primary  my-2">Address</h3>
                    <div class="row">
                        @foreach($user_addresses as $addr)
                        <div class="col-sm-6 my-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title text-primary">{{ucfirst($addr->address_type)}}</h5>
                                    <p class="card-text">{{ucfirst($addr->address)}}</p>
                                    <a href="{{route('delete-address', [$addr->id])}}" class="text-danger mx-2"><i class="fa fa-trash"></i></a>
                                    <a href="{{route('edit-address', [$addr->id])}}">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="tab-pane fade " id="v-pills-order" role="tabpanel" aria-labelledby="v-pills-order-tab">
                <div class="container p-5">
                    <h3 class="text-primary  my-2">Orders</h3>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="col-6 nav-link active" id="nav-Running-tab" data-bs-toggle="tab" data-bs-target="#nav-Running" type="button" role="tab" aria-controls="nav-Running" aria-selected="true">Running</button>
                            <button class="col-6 nav-link" id="nav-History-tab" data-bs-toggle="tab" data-bs-target="#nav-History" type="button" role="tab" aria-controls="nav-History" aria-selected="false">History</button>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-Running" role="tabpanel" aria-labelledby="nav-Running-tab">
                            <div class="accordion" id="accordionExample">
                                @foreach($orders as $key => $order)
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading{{$key}}">
                                        <button style="    padding: 5px;" class="accordion-button {{ $key ? 'collapsed' : '' }}" type="button" data-bs-toggle="collapse" data-bs-target="#collapse{{$key}}" aria-expanded="true" aria-controls="collapse{{$key}}">
                                            <img class="rounded mx-2" style="width: 70px ; height:70px;" data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($order->store->logo, asset('storage/app/public/store/') . '/' . $order->store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}" alt="">
                                            <div>
                                                Order Id : #{{$order->id}} <br>
                                                {{ date('d M Y  H:i', strtotime($order->created_at)) }}

                                            </div>
                                            <span class="badge bg-success mx-2">{{$order->order_status}}</span>
                                        </button>
                                    </h2>
                                    <div id="collapse{{$key}}" class="accordion-collapse collapse {{!$key? 'show' : '' }} " aria-labelledby="heading{{$key}}" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <th>Order Id</th>
                                                        <td>{{$order->id}}</td>
                                                        <th>Order Date</th>
                                                        <td>{{ date('d M Y  H:i', strtotime($order->created_at)) }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td>{{ucfirst($order->order_type)}}</td>
                                                        <td>{{ ucfirst(str_replace("_", " ", $order->payment_method))}}</td>
                                                        <td><span class="text-primary">{{ucfirst($order->order_status)}}</span></td>
                                                        <th>Items: {{$order->details_count}}</th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <h5>Item Info</h5>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Products</th>
                                                        <th scope="col">Quantity</th>
                                                        <th scope="col">Total Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                    $total_price = 0;
                                                    @endphp
                                                    @foreach($order['items'] as $key => $o_item)

                                                    @php
                                                    $total_price += $o_item->price;
                                                    $ct = json_decode($o_item->item_details);
                                                    $variation = json_decode($o_item->variation);
                                                    @endphp

                                                    <tr>
                                                        <th scope="row">
                                                            <div class="d-flex align-items-center mt-2">
                                                                <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct->image, asset('storage/app/public/product/') . '/' . $ct->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}" class="img-fluid rounded-circle" style="width: 50px; height: 50px;" alt="">
                                                                {{$ct->name}} ({{$variation[0]->type}})
                                                            </div>
                                                        </th>

                                                        <td>{{$o_item->quantity}}</td>
                                                        <td class="">{{ \App\CentralLogics\Helpers::currency_symbol() .  $o_item->price}}</td>
                                                    </tr>

                                                    @endforeach

                                                </tbody>
                                            </table>
                                            <div class="row">
                                                <div class="col-6">
                                                    @php $delDetails = json_decode($order->delivery_address ) @endphp
                                                    <h5>Deliver To </h5>
                                                    <div class="card p-2">
                                                        <b>{{$delDetails->contact_person_name}}</b>
                                                        {{$delDetails->address}}
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <h5>Store Details</h5>
                                                    <div class="card d-flex flex-row align-items-center p-1">
                                                        <img class="rounded mx-2" style="width: 56px ; height:56px;" data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($order->store->logo, asset('storage/app/public/store/') . '/' . $order->store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}" alt="">
                                                        {{$order->store->name}}
                                                    </div>
                                                </div>
                                            </div>

                                            <table class="table table-borderless w-50 mt-4">
                                                <tbody>
                                                    <tr>
                                                        <td>Item Price</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() .$total_price}}</td>
                                                    </tr>
                                                    @if($order->store_discount_amount)
                                                    <tr>
                                                        <td>Discount</td>
                                                        <td>(-){{\App\CentralLogics\Helpers::currency_symbol() . $order->store_discount_amount}}</td>
                                                    </tr>
                                                    @endif
                                                    <tr>
                                                        <td>VAT/TAX</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() . $order->total_tax_amount}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Delivery Fee</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() .$order->original_delivery_charge}}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Total Amount</th>
                                                        <td> <span class="fs-5">{{\App\CentralLogics\Helpers::currency_symbol() .$order->order_amount}}</span> </td>
                                                    </tr>
                                                </tbody>
                                            </table>


                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        <div class="tab-pane fade " id="nav-History" role="tabpanel" aria-labelledby="nav-History-tab">
                            <div class="accordion" id="accordionExample">
                                @if(count($p_orders))
                                @foreach($p_orders as $key => $order)
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading{{$key}}">
                                        <button style="    padding: 5px;" class="accordion-button {{ $key ? 'collapsed' : '' }}" type="button" data-bs-toggle="collapse" data-bs-target="#collapse{{$key}}" aria-expanded="true" aria-controls="collapse{{$key}}">
                                            <img class="rounded mx-2" style="width: 70px ; height:70px;" data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($order->store->logo, asset('storage/app/public/store/') . '/' . $order->store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}" alt="">
                                            <div>
                                                Order Id : #{{$order->id}} <br>
                                                {{ date('d M Y  H:i', strtotime($order->created_at)) }}

                                            </div>
                                            <span class="badge bg-success mx-2">{{$order->order_status}}</span>
                                        </button>
                                    </h2>
                                    <div id="collapse{{$key}}" class="accordion-collapse collapse {{!$key? 'show' : '' }} " aria-labelledby="heading{{$key}}" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <th>Order Id</th>
                                                        <td>{{$order->id}}</td>
                                                        <th>Order Date</th>
                                                        <td>{{ date('d M Y  H:i', strtotime($order->created_at)) }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td>{{ucfirst($order->order_type)}}</td>
                                                        <td>{{ ucfirst(str_replace("_", " ", $order->payment_method))}}</td>
                                                        <td><span class="text-primary">{{ucfirst($order->order_status)}}</span></td>
                                                        <th>Items: {{$order->details_count}}</th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <h5>Item Info</h5>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Products</th>
                                                        <th scope="col">Quantity</th>
                                                        <th scope="col">Total Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                    $total_price = 0;
                                                    @endphp
                                                    @foreach($order['items'] as $key => $o_item)

                                                    @php
                                                    $total_price += $o_item->price;
                                                    $ct = json_decode($o_item->item_details);
                                                    $variation = json_decode($o_item->variation);
                                                    @endphp

                                                    <tr>
                                                        <th scope="row">
                                                            <div class="d-flex align-items-center mt-2">
                                                                <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct->image, asset('storage/app/public/product/') . '/' . $ct->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}" class="img-fluid rounded-circle" style="width: 50px; height: 50px;" alt="">
                                                                {{$ct->name}} ({{$variation[0]->type}})
                                                            </div>
                                                        </th>

                                                        <td>{{$o_item->quantity}}</td>
                                                        <td class="">{{ \App\CentralLogics\Helpers::currency_symbol() .  $o_item->price}}</td>
                                                    </tr>

                                                    @endforeach

                                                </tbody>
                                            </table>
                                            <div class="row">
                                                <div class="col-6">
                                                    @php $delDetails = json_decode($order->delivery_address ) @endphp
                                                    <h5>Deliver To </h5>
                                                    <div class="card p-2">
                                                        <b>{{$delDetails->contact_person_name}}</b>
                                                        {{$delDetails->address}}
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <h5>Store Details</h5>
                                                    <div class="card d-flex flex-row align-items-center p-1">
                                                        <img class="rounded mx-2" style="width: 56px ; height:56px;" data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($order->store->logo, asset('storage/app/public/store/') . '/' . $order->store->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}" alt="">
                                                        {{$order->store->name}}
                                                    </div>
                                                </div>
                                            </div>

                                            <table class="table table-borderless w-50 mt-4">
                                                <tbody>
                                                    <tr>
                                                        <td>Item Price</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() .$total_price}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>VAT/TAX</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() .$order->total_tax_amount}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Delivery Fee</td>
                                                        <td>{{\App\CentralLogics\Helpers::currency_symbol() .$order->original_delivery_charge}}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Total Amount</th>
                                                        <td> <span class="fs-5">{{\App\CentralLogics\Helpers::currency_symbol() .$order->order_amount}}</span> </td>
                                                    </tr>
                                                </tbody>
                                            </table>


                                        </div>
                                    </div>
                                </div>
                                @endforeach
                                @else
                                <p class="text-center my-5"> No previous orders...</p>
                                @endif
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                <div class="container p-5">
                    <h3 class="text-primary  my-2">Favourites</h3>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="col-6 nav-link active" id="nav-items-tab" data-bs-toggle="tab" data-bs-target="#nav-items" type="button" role="tab" aria-controls="nav-items" aria-selected="true">Items</button>
                            <button class=" col-6 nav-link" id="nav-stores-tab" data-bs-toggle="tab" data-bs-target="#nav-stores" type="button" role="tab" aria-controls="nav-stores" aria-selected="false">Stores</button>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-items" role="tabpanel" aria-labelledby="nav-items-tab">

                            @if(count($wishlists['items']))
                            @foreach($wishlists['items'] as $ct)

                            <div class="card my-3">
                                <div class="row g-0">
                                    <div class="col-md-3 p-3">
                                        <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct->image, asset('storage/app/public/product/') . '/' . $ct->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}" class="img-fluid rounded" alt="">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title">{{$ct->name}}</h5>
                                            <p class="card-text">{{_limitDesc($ct->description, 150)}}</p>
                                            <p class="card-text"><small class="text-muted">
                                                    {{\App\CentralLogics\Helpers::currency_symbol() . _discountedPrice($ct->price, $ct->discount, $ct->discount_type ) }}
                                                    @if($ct->discount)
                                                    <span class="text-danger text-decoration-line-through mb-0" style="white-space: nowrap;">{{ \App\CentralLogics\Helpers::currency_symbol()}} {{ floor($ct->price)   }}</span>
                                                    @endif
                                                </small></p>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            @endforeach
                            @else
                            <div class="container d-flex flex-column align-items-center justify-content-center" style="height:200px">
                                <p>No items in wishlist...</p>
                                <a href="{{route('home')}}#products" class="btn btn-danger"><i class="fa fa-heart text-white"></i> Wish Now</a>
                            </div>
                            @endif

                        </div>
                        <div class="tab-pane fade" id="nav-stores" role="tabpanel" aria-labelledby="nav-stores-tab">
                            <div id="wishTabInner">
                                @if(count($wishlists['stores']))
                                <div class="row">

                                    @foreach($wishlists['stores'] as $ct)

                                    <div class="card my-3 col-5 m-1 position-relative">
                                        <a onclick="removeWishlist('store', '{{$ct->id}}')" class="position-absolute" style="right:10px; top:10px;cursor:pointer;"><i class="fa fa-heart text-danger fs-4"></i></a>
                                        <div class="row">
                                            <div class="col-md-4 p-3">
                                                <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct->logo, asset('storage/app/public/store/') . '/' . $ct->logo, asset('public/assets/admin/img/160x160/img1.jpg'), 'store/') }}" class="img-fluid rounded" alt="">
                                            </div>
                                            <div class="col-md-7">
                                                <div class="card-body">
                                                    <h5 class="card-title">{{$ct->name}}</h5>
                                                    <p class="card-text">{{$ct->address}}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    @endforeach
                                </div>
                                @else
                                <div class="container d-flex flex-column align-items-center justify-content-center" style="height:200px">
                                    <p>No favourite stores ...</p>
                                    <a href="{{route('home')}}#stores" class="btn btn-danger"><i class="fa fa-heart text-white"></i> Explore stores</a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModalLogout" tabindex="-1" aria-labelledby="exampleModalLogoutLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLogoutLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="f-4">Are you sure you want to logout?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="{{route('user.logout')}}" class="btn btn-primary">Yes</a>
            </div>
        </div>
    </div>
</div>

@endsection

@push('script_2')

<script>
    function removeWishlist(type, id) {

        var url = "{{ route('remove-from-wishlist', ['type' => 'TYPE', 'id'=> 'ID']) }}";
        var url = url.replace('TYPE', type).replace('ID', id);

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.get({
            url: url,
            data: {
                type: type
            },
            beforeSend: function() {
                $('#loading').show()
            },
            success: function(data) {
                toasterNotification(data.message)
                $('#nav-stores').load(window.location.href + ' #wishTabInner')
            },
            complete: function() {
                $('#loading').hide()
            }
        });
    }
</script>

@endpush