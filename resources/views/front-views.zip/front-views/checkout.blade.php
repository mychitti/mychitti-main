@extends('front-views.layout')

@section('title','Checkout')

@push('css_or_js')
  <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')

        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Checkout</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                <li class="breadcrumb-item active text-white">Checkout</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Checkout Page Start -->
        <div class="container-fluid py-5">
            <div class="container py-5">
                <h1 class="mb-4">Billing details</h1>
                <form action="#">
                    <div class="row g-5">
                        <div class="col-md-12 col-lg-6 col-xl-7">
                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">First Name<sup>*</sup></label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">Last Name<sup>*</sup></label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Company Name<sup>*</sup></label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Address <sup>*</sup></label>
                                <input type="text" class="form-control" placeholder="House Number Street Name">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Town/City<sup>*</sup></label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Country<sup>*</sup></label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Postcode/Zip<sup>*</sup></label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Mobile<sup>*</sup></label>
                                <input type="tel" class="form-control">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Email Address<sup>*</sup></label>
                                <input type="email" class="form-control">
                            </div>
                            <div class="form-check my-3">
                                <input type="checkbox" class="form-check-input" id="Account-1" name="Accounts" value="Accounts">
                                <label class="form-check-label" for="Account-1">Create an account?</label>
                            </div>
                            <hr>
                            <div class="form-check my-3">
                                <input class="form-check-input" type="checkbox" id="Address-1" name="Address" value="Address">
                                <label class="form-check-label" for="Address-1">Ship to a different address?</label>
                            </div>
                            <div class="form-item">
                                <textarea name="text" class="form-control" spellcheck="false" cols="30" rows="11" placeholder="Oreder Notes (Optional)"></textarea>
                            </div>
                        </div> 
                        <div class="col-md-12 col-lg-6 col-xl-5">
                            <div class="mb-2">
                                <a href="{{route('store.details', [$store->slug])}}" > + Add more items</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table"> 
                                    <thead>
                                        <tr>
                                            <th scope="col">Products</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @php $item_total = 0;
                                    $cart_total = 0 ;
                                    @endphp
                                    @foreach($cart as $ct)
                                    @php $item_total += $ct->item_price;
                                    $cart_total += $ct->price;
                                    @endphp  
                                        <tr>
                                            <th scope="row">
                                                <div class="d-flex align-items-center mt-2">
                                                    <img data-onerror-image="{{ asset('public/assets/admin/img/160x160/img1.jpg') }}" src="{{ \App\CentralLogics\Helpers::onerror_image_helper($ct->image, asset('storage/app/public/product/') . '/' . $ct->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}" class="img-fluid rounded-circle" style="width: 50px; height: 50px;" alt="">
                                                </div>
                                            </th>
                                            @php $variations = json_decode(json_decode($ct->variation, true), true) ; @endphp
                                            <td class="">{{$ct->name}} {{ empty($variations) ? '' : '('. $variations[0]['type'] . ')' }}</td>
                                            <td class="">
                                            {{\App\CentralLogics\Helpers::currency_symbol() . _discountedPrice($ct->item_price, $ct->item_discount, $ct->discount_type ) }} 
                                            @if($ct->item_discount) 
                                            <p class="text-danger text-decoration-line-through mb-0" style="white-space: nowrap;">{{ \App\CentralLogics\Helpers::currency_symbol()}} {{  floor($ct->item_price)   }}</p>
                                            @endif  
                                            </td> 
                                            <td class="">{{$ct->quantity}}</td>
                                            <td class="">{{ \App\CentralLogics\Helpers::currency_symbol() .  $ct->price}}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
 
                            <div class="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                <div class="col-12 row">
                                    @if($store->delivery)
                                    <label for="Delivery-1" style="cursor:pointer" class="col-5 form-check text-start my-3 border rounded border-primary py-3 mx-1 px-1">
                                        <input type="radio" checked style="cursor:pointer" class="form-check-input bg-primary border-0 mx-1" id="Delivery-1" name="Delivery" value="Delivery">
                                       Home Delivery
                                    </label>
                                    @endif
                                    @if($store->take_away)
                                    <label  for="Delivery-2" class="col-5 form-check text-start my-3 border rounded border-primary py-3 px-1">
                                        <input type="radio" class="form-check-input bg-primary border-0 mx-1" id="Delivery-2" name="Delivery" value="Delivery">
                                        Take Away
                                    </label>
                                    @endif
                                </div>
                                Delivery Charge : {{ \App\CentralLogics\Helpers::currency_symbol() . 0 }}
                            </div>
                          
                            <div class="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                <div class="col-12">
                                    <div class="form-check text-start my-3">
                                        <input checked type="checkbox" class="form-check-input bg-primary border-0" id="Delivery-1" name="Delivery" value="Delivery">
                                        <label class="form-check-label" for="Delivery-1">Cash On Delivery</label>
                                    </div>
                                </div>
                            </div>
                             
                            <div class="row g-4 text-center align-items-center justify-content-center pt-4">
                                <button type="button" class="btn border-secondary py-3 px-4 text-uppercase w-100 text-primary">Place Order</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Checkout Page End -->

@endsection

@push('script_2')

@endpush