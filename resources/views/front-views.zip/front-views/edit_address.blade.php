@extends('front-views.layout')

@section('title','Edit Address')

@push('css_or_js')
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
    #map {
        height:300px;
        width: 100%;
    }
</style>
<script src="https://maps.googleapis.com/maps/api/js?key={{\App\Models\BusinessSetting::where('key', 'map_api_key')->first()->value}}&libraries=places"></script>

<script>
    function loadScript(src, callback) {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.async = true;
        script.src = src;
        script.onload = callback;
        document.head.appendChild(script);
    }

    function initMap() {
        var initialLocation = {
            lat: {{$addr->latitude}},
            lng: {{$addr->longitude}}
        }; 
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 8,
            center: initialLocation
        });

        var marker = new google.maps.Marker({
            position: initialLocation,
            map: map,
            draggable: true
        });

        var geocoder = new google.maps.Geocoder();
        var infoWindow = new google.maps.InfoWindow();

        google.maps.event.addListener(marker, 'dragend', function(event) {
            var lat = event.latLng.lat();
            var lng = event.latLng.lng();

            geocoder.geocode({
                'location': {
                    lat: lat,
                    lng: lng
                }
            }, function(results, status) {
                if (status === 'OK') {
                    if (results[0]) {
                        // map.setZoom(11);
                        var address = results[0].formatted_address;
                        // document.getElementById('info').innerHTML =
                        //     'Address: ' + address + '<br>Coordinates: ' + lat + ', ' + lng;
                            $('#address_field').val(address);
                            $('#address_hid').val(address);
                            $('#latitude').val(lat)
                            $('#longitude').val(lng)
                    } else {
                        window.alert('No results found');
                    }
                } else {
                    window.alert('Geocoder failed due to: ' + status);
                }
            });
        });
    }

    function init() {
        loadScript('https://maps.googleapis.com/maps/api/js?key=AIzaSyDfkQ1xLl-olEuR67KY49xp3FAlaLwVBso&libraries=places&callback=initMap');
    }

    window.onload = init;
</script>
@endpush

@section('content')

<!-- Contact Start -->
<div class="container-fluid contact py-5">
    <div class="container py-5">
        <div class="p-5 bg-light rounded">
            <form class="formSubmit addressForm" action="{{route('update-address', [$addr->id])}}" method="post">
                @csrf
                <div class="row ">
                    <div class="col-md-12 row">
                        <div class="row">
                            <div class="rounded p-2 d-flex flex-column position-relative align-items-center" style="height: fit-content;">
                                <div id="map"></div>
                                <!-- <p id="info"></p> -->
                            </div>

                            <div class="col-12 row">
                                <input type="hidden" name="latitude" id="latitude" value="{{$addr->latitude}}">
                                <input type="hidden" name="longitude" id="longitude" value="{{$addr->longitude}}">
                                <input type="hidden" name="address" id="address_hid" value="{{$addr->address}}">
                                <label for="Delivery-1" style="cursor:pointer" class="col-2 form-check text-start my-3 border rounded border-primary py-3 mx-1 px-1">
                                    <input type="radio" {{$addr->address_type == 'home'? 'checked' : ''}} style="cursor:pointer" class="form-check-input bg-primary border-0 mx-1" id="Delivery-1" name="address_type" value="home">
                                    Home
                                </label> 
                                <label for="Delivery-2" style="cursor:pointer" class="col-2 form-check text-start my-3 border rounded border-primary py-3  mx-1 px-1">
                                    <input type="radio" {{$addr->address_type == 'office'? 'checked' : ''}} class="form-check-input bg-primary border-0 mx-1" id="Delivery-2" name="address_type" value="office">
                                    Work
                                </label>
                                <label for="Delivery-3" style="cursor:pointer" class="col-2 form-check text-start my-3 border rounded border-primary py-3  mx-1 px-1">
                                    <input type="radio" {{$addr->address_type == 'others'? 'checked' : ''}} class="form-check-input bg-primary border-0 mx-1" id="Delivery-3" name="address_type" value="others">
                                    Other
                                </label>

                            </div>
                            <div class="col-md-12 col-lg-12">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Address<sup>*</sup></label>
                                    <input type="text" disabled name="" id="address_field" name="address" value="{{$addr->address}}" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Contact Person Name<sup>*</sup></label>
                                    <input type="text" name="contact_person_name" required value="{{$addr->contact_person_name}}" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Contact Person Mobile</label>
                                    <input value="{{$addr->contact_person_number}}" name="contact_person_number" type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-12">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Street Number</label>
                                    <input value="{{$addr->road}}" name="road" type="text" placeholder="(Optional)" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">House</label>
                                    <input value="{{$addr->house}}" name="house" type="text" placeholder="(Optional)" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Floor</label>
                                    <input value="{{$addr->floor}}" name="floor" type="text" placeholder="(Optional)" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn border-secondary text-primary">Update</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Contact End -->

@endsection

@push('script_2')

@endpush