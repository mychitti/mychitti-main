@extends('front-views.layout')

@section('title',$store['name'])

@section('metatitle' , $store['meta_title'])
@section('meta_description' , $store['meta_description'])


@push('css_or_js')
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
    .store-hero {
        position: relative;
    }

    .hero_content {
        z-index: 1;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background: #ffffffc4;
        width: 70%;
        display: flex;
        justify-content: space-between;
        padding: 20px;
        border-radius: 20px;
    }

    .hero_content .store_logo {
        height: 200px;
        width: 200px;
    }

    .store_cover {
        height: 500px;
        width: 100%;
        object-fit: cover;
    }

    .utility_div {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
</style>
@endpush

@section('content')
<div class="spacer" style="height: 153px;"></div>
<div class="store-hero">
    <div class="hero_content">
        <div class="content_inner d-flex " style="color:black">
            <img class="store_logo" src="{{asset('storage/app/public/store/').'/'.$store['logo']}}">
            <div class="p-3">
                <h3 style="color:black"> {{ $store['name'] }}</h3>
                <p>{{$store['address']}}</p>
                <p>Minimum Order Amount {{\App\CentralLogics\Helpers::currency_symbol() . $store['minimum_order']}}</p>
                <div class="other_info d-flex justify-content-between" style="width:380px">

                    <div>
                        <i class="fa fa-star"></i>  {{$store['avg_rating']}} <br>
                    {{$store['rating_count']}} + ratings
                    </div>
                    <div>
                        <i class="fas fa-map-marker-alt"></i><br>
                        Location
                    </div>
                    <div>
                        <i class="fa fa-clock"></i>{{$store['delivery_time']}}<br>
                        Delivery Time
                    </div>
                </div>
            </div>
        </div>
        <div class="utility_div">
            <div class="wishlix">
                <i class="fa fa-heart fs-1"></i>
            </div>
            <div>
                @if($store['open'])
                <h4 class="text-success">Open</h4>
                @else
                <h4 class="text-danger">Closed</h4>
                @endif
            </div>
        </div>
    </div>
    <img class="store_cover" src="{{asset('storage/app/public/store/cover/').'/'.$store['cover_photo']}}" alt="">
</div>
<div class="row g-4"> 
<!-- products  -->


  <!-- Fruits Shop Start--> 
  <div class="container-fluid fruite py-5">
            <div class="container py-5">
                <div class="tab-class text-center">
                    <div class="row g-4">
                        <div class="col-lg-4 text-start">
                            <h1>Products</h1>
                        </div>
                        <div class="col-lg-8 text-end">
                            <ul class="nav nav-pills d-inline-flex text-center mb-5">
                                <!-- <li class="nav-item"> 
                                    <a class="d-flex m-2 py-2 bg-light rounded-pill active" data-bs-toggle="pill" href="#tab--1">
                                        <span class="text-dark" style="width: 130px;">All Products</span>
                                    </a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div id="tab-1" class="tab-pane fade show p-0 active">
                            <div class="row g-4">
                                <div class="col-lg-12">
                                    <div class="row g-4"> 
                                    @foreach( $productdata['items'] as $pro)
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="rounded position-relative fruite-item">
                                            <div class="fruite-img" style="height: 290px !important;  border: 1px solid #ffb524;  border-bottom: 0px;"> 
                                                <img data-onerror-image="{{asset('public/assets/admin/img/160x160/img1.jpg')}}"
                                                src="{{\App\CentralLogics\Helpers::onerror_image_helper($pro->image, asset('storage/app/public/product/').'/'.$pro->image, asset('public/assets/admin/img/160x160/img1.jpg'), 'product/') }}"  class="img-fluid w-100 rounded-top" alt="">
                                            </div>
                                            <div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;">{{ $pro->discount_type == 'amount'? \App\CentralLogics\Helpers::currency_symbol(). $pro->discount . ' Off' :  $pro->discount . ' %Off'}}</div>
                                            <div class="p-4 border border-secondary border-top-0 rounded-bottom">
                                                <h4>{{ucfirst($pro->name)}}</h4>
                                                <p>{{ucfirst($pro->description)}}</p>
                                                <div class="d-flex justify-content-between flex-lg-wrap">
                                                    <p class="text-dark fs-5 fw-bold mb-0">{{\App\CentralLogics\Helpers::currency_symbol() . $pro->price}}</p>
                                                    <a href="#" class="btn border border-secondary rounded-pill px-3 text-primary"><i class="fa fa-shopping-bag me-2 text-primary"></i> Add to cart</a>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
                                    @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>      
            </div>
        </div>
        <!-- Fruits Shop End-->

 </div>
@endsection

@push('script_2')

@endpush