<?php

namespace App\Http\Controllers\Front;

use App\CentralLogics\Helpers;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Order;
use MatanYadaev\EloquentSpatial\Objects\Point;
use App\Models\Zone;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;
use App\Models\CustomerAddress;
use App\Models\OrderDetail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use App\Models\Module;
use App\Models\Wishlist;

class UserController extends Controller
{

    private $latitude;
    private $longitude;
    private $module;
    private $zone_id;

    public function __construct()
    {
         /*$this->middleware('auth');*/
         $this->latitude = 79.47064686566591;
         $this->longitude = 13.661511242910333;
         $this->module = Module::find('5');
         $this->zone_id = json_encode(['5', '1']);
 
         Config::set('module.current_module_data',  $this->module);
    }

    public function login()
    {
        return view('front-views.login');
    }

    public function logout(){

        auth()->guard('web')->logout();
    
        return redirect()->route('home');
    }

    public function login_attempt(Request $request)
    {
    }

    public function dashboard(Request $request)
    {
        $user_id = auth('web')->user() ? auth('web')->user()->id : session()->get('guest_id');
        $is_guest = auth('web')->user() ? 0 : 1;

        // user details =================
        $user_details = User::where('id', $user_id)->first();
        $user_addresses = CustomerAddress::where('user_id', $user_id)->get();

        // current orders ================
        $orders = Order::with(['store', 'delivery_man.rating', 'parcel_category'])->where('is_guest', $is_guest)
            ->withCount('details')->where(['user_id' => $user_id])->whereNotIn('order_status', ['delivered', 'canceled', 'refund_requested', 'refund_request_canceled', 'refunded', 'failed'])->Notpos()->get();
        foreach ($orders as $key => $value) {
            $orders[$key]['items'] = DB::table('order_details')
                ->where('order_details.order_id', $value->id)
                ->get();
        }

        // previous orders =================
        $p_orders = Order::with(['store', 'delivery_man.rating', 'parcel_category', 'refund:order_id,admin_note,customer_note'])->withCount('details')->where(['user_id' => $user_id])->whereIn('order_status', ['delivered', 'canceled', 'refund_requested', 'refund_request_canceled', 'refunded', 'failed'])->where(['user_id' => $user_id])
            ->Notpos()->get();

        // wishlist ================
        $wishlists['items'] = DB::table('wishlists')->where('user_id', $user_id)
        ->join('items', 'items.id', 'wishlists.item_id')
        ->whereNotNull('wishlists.item_id')
        ->select('items.*', 'wishlists.id')
        ->get();

        // prx( $wishlists['items'][0]);    

        $wishlists['stores'] =  DB::table('wishlists')->where('user_id', $user_id)
        ->join('stores', 'stores.id', 'wishlists.store_id')
        ->select('stores.*', 'wishlists.id')
        ->whereNotNull('wishlists.store_id')->get();
       
        return view('front-views.dashboard', compact('user_details', 'user_addresses', 'orders', 'p_orders', 'wishlists'));
    }

    
    public function remove_wishlist(Request $request, $type, $id){

        Wishlist::where('id', $id)->delete();
        return response()->json(['status'=> true, 'message' => 'Removed Successfully']);

    }
    public function delete_address(Request $request)
    {
        CustomerAddress::find($request->id)->delete();
        return back();
    }

    public function edit_address(Request $request)
    {
        $addr = CustomerAddress::find($request->id);
        return view('front-views.edit_address', compact('addr'));
    }

    public function update_address(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'contact_person_name' => 'required',
            'address_type' => 'required',
            'contact_person_number' => 'required',
            'address' => 'required',
            'longitude' => 'required',
            'latitude' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }
        $zone = Zone::whereContains('coordinates', new Point($request->latitude, $request->longitude, POINT_SRID))->get(['id']);
        if (!$zone) {
            $errors = [];
            array_push($errors, ['code' => 'coordinates', 'message' => translate('messages.service_not_available_in_this_area')]);
            return response()->json([
                'errors' => $errors
            ], 403);
        }
        $address = [
            'user_id' => $request->user()->id,
            'contact_person_name' => $request->contact_person_name,
            'contact_person_number' => $request->contact_person_number,
            'address_type' => $request->address_type,
            'address' => $request->address,
            'floor' => $request->floor,
            'road' => $request->road,
            'house' => $request->house,
            'longitude' => $request->longitude,
            'latitude' => $request->latitude,
            'zone_id' => $zone[0]->id,
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('customer_addresses')->where('id', $id)->update($address);
        return response()->json(['message' => translate('messages.updated_successfully'), 'zone_id' => $zone[0]->id], 200);
    }

    public function update_profile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'f_name' => 'required',
            'l_name' => 'required',
            'email' => 'required|unique:users,email,' . $request->user()->id,
            'password' => ['nullable', Password::min(8)],
        ], [
            'f_name.required' => 'First name is required!',
            'l_name.required' => 'Last name is required!',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $image = $request->file('image');

        if ($request->has('image')) {
            $imageName = Helpers::update('profile/', $request->user()->image, 'png', $request->file('image'));
        } else {
            $imageName = $request->user()->image;
        }

        if ($request['password'] != null && strlen($request['password']) > 5) {
            $pass = bcrypt($request['password']);
        } else {
            $pass = $request->user()->password;
        }

        $user = User::where(['id' => $request->user()->id])->first();
        $user->f_name = $request->f_name;
        $user->l_name = $request->l_name;
        $user->email = $request->email;
        $user->image = $imageName;
        $user->password = $pass;
        $user->save();

        if ($user->userinfo) {
            $userinfo = $user->userinfo;
            $userinfo->f_name = $request->f_name;
            $userinfo->l_name = $request->l_name;
            $userinfo->email = $request->email;
            $userinfo->image = $imageName;
            $userinfo->save();
        }

        return response()->json(['message' => translate('messages.successfully_updated')]);
    }
}
