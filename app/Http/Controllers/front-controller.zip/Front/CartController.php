<?php

namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Cart;
use App\Models\Item;
use App\Models\ItemCampaign;
use App\CentralLogics\Helpers;

class CartController extends Controller
{
    
    public function __construct()
    {
        /*$this->middleware('auth');*/
    }
    public function add_to_cart(Request $request)
    {
        $user_id = auth('web')->user() ? auth('web')->user()->id : session()->get('guest_id') ;
        $is_guest = auth('web')->user() ? 0 : 1;
        $item_id = $request->prId;
        $item =  Item::find($item_id);
        // prx($item->variations);
        $price = _discountedPrice($item->price, $item->discount,  $item->discount_type) ;
        $quantity = 1;
        $model = 'App\Models\Item';

        $variations = json_decode($item->variations);

        if($request->variation != 0){
            $variation =  '['.json_encode($variations[0]) . ']' ;
        }else{
             $variation = json_encode([]);
        }

        $cart = Cart::where('item_id',$item_id)->where('item_type',$model)->where('variation',json_encode($variation))->where('user_id', $user_id)->where('is_guest',$is_guest)->where('module_id',5)->first();

        if($cart){
            return response()->json(['status' => false, 'message' => 'Item already exists in cart']);
        }

        if($item->maximum_cart_quantity && ($quantity>$item->maximum_cart_quantity)){
            return response()->json(['status' => false, 'message' => 'Maximum cart quantity exceeded']);
        }
      
        $cart = new Cart();
        $cart->user_id = $user_id;
        $cart->module_id = 5;
        $cart->item_id = $item_id;
        $cart->is_guest = $is_guest;
        $cart->add_on_ids = json_encode([]);
        $cart->add_on_qtys = json_encode([]);
        $cart->item_type = $model;
        $cart->price = $price;
        $cart->quantity = $quantity;
        $cart->variation =  $variation ;
        $cart->save();

        $item->carts()->save($cart);

        return response()->json(['status' => true, 'message' => _randomAddCartMsg(), 'cart_id' => $cart->id, 'firstvr' => 1 ]);
    }

    public function remove_from_cart(Request $request){

        $cart = Cart::find($request->cart_id);
        if( $cart->variation == '[]'){
            $vrCount = 0;
        }else{
            $vrCount = 1;
        }

        if($cart->delete()){
            return response()->json(['status' => true, 'message' => "Item removed from cart!", 'firstVr' => $vrCount]);
        }else{
            return response()->json(['status' => false, 'message' => "Some error occured", 'firstVr' => $vrCount]);
        }

    }

    public function change_cart_quantity(Request $request){
        $user_id = auth('web')->user() ? auth('web')->user()->id : session()->get('guest_id') ;
        $is_guest = auth('web')->user() ? 0 : 1;
        $cart = Cart::where('id',$request->cartId)->where('user_id', $user_id)->where('is_guest',$is_guest)->where('module_id',5)->first();
    //    prx($cart);
        if($request->action == 'increase'){
            $cart->quantity += 1;
            $cart->price += $cart->price;
        }else{
            $cart->quantity -= 1;
            $cart->price -= $cart->price;
        }
        if($cart->save()){
            return response()->json(['status' => true, 'message' => "Cart Updated successfully"]);
        }else{
            return response()->json(['status' => false, 'message' => "Some error occured"]);
        }
    }
  
}


