<?php

namespace App\Http\Controllers\Front;

use App\CentralLogics\BannerLogic;
use App\CentralLogics\Helpers;
use App\Models\ServiceRequest;
use App\CentralLogics\CategoryLogic;
use App\Http\Controllers\Controller;
use App\Http\Controllers\CategoryController;
use App\CentralLogics\StoreLogic;
use App\CentralLogics\ProductLogic;
use App\Http\Controllers\Api\V1\CategoryController as V1CategoryController;
use App\Http\Controllers\Api\V1\OtherBannerController;
use App\Models\Contact;
use Illuminate\Http\Request;
use App\Models\AdminFeature;
use App\Models\AdminPromotionalBanner;
use App\Models\AdminSpecialCriteria;
use App\Models\AdminTestimonial;
use App\Models\BusinessSetting;
use App\Models\DataSetting;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\File;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Config;
use App\Models\Module;

use App\Http\Controllers\Api\V1\StoreController;
use App\Models\Campaign;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Item;
use App\Models\ModuleWiseBanner;
use App\Models\Store;
use Illuminate\Support\Facades\DB;

class FrontController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    private $latitude;
    private $longitude;
    private $module;
    private $zone_id;
     
    public function __construct()
    {
        /*$this->middleware('auth');*/
        $this->latitude = 20.755860;
        $this->longitude = 77.668580;
        $this->module = Module::find('5');
        $this->zone_id = json_encode(['5', '1']);

        Config::set('module.current_module_data',  $this->module);

        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
       
        $module = $this->module; 
        Config::set('module.current_module_data', $module);
        $module_id = config('module.current_module_data')['id'];
        $type =  'all';
        $store_type =  'all';
        $zone_id = $this->zone_id; 
        $longitude = $this->longitude;
        $latitude = $this->latitude;

        // featured stores
        $stores = StoreLogic::get_stores( $zone_id, 'all', $type, $store_type, 5, 1, 1,$longitude,$latitude);
        $stores['featued_stores'] = Helpers::store_data_formatting($stores['stores'], true);

        // prx( $stores['featued_stores']);
     
        // new on my chitti 
        $stores2 = StoreLogic::get_latest_stores($zone_id, 6, 1, $type,$longitude,$latitude);
        $stores['new_stores'] = Helpers::store_data_formatting($stores2['stores'], true);

        // special offer 
        $category_ids = '';
        $items['special_products'] = ProductLogic::discounted_products($zone_id, 4, 1, $type, $category_ids)['products'];
        // prx($items['special_products'][0]->name);
        // $items['special_products'] = Helpers::product_data_formatting($items['products'], true, false, app()->getLocale());
        // die('33'); 
   
        //products
        $data['cats'] = Category::withCount(['products','childes'=> function($query){
            $query->where('status',1);
        } ]) 
        ->where(['position'=>0,'status'=>1, 'featured' => 1])
        ->when(config('module.current_module_data'), function($query){
            $query->module(config('module.current_module_data')['id']);
        })->orderBy('priority','desc')->get();

        // prx($data['cats'][0]['products_count']);

        // categories
        $catController = new V1CategoryController();
        $resp = $catController->get_categories($request);
        $data['h_categories'] = json_decode($resp->getContent(), true);

        //banners 
        $data['banners'] = BannerLogic::get_banners($zone_id, 0);

             
    
        return view('front-views.home', compact('stores', 'data', 'items'));
    }
    public function contact()
    {
       return view('front-views.contact');
    }
    public function cart()
    {
        $user_id = auth('web')->user() ? auth('web')->user()->id : session()->get('guest_id') ;
        $is_guest = auth('web')->user() ? 0 : 1;

        $cart = DB::table('carts')
        ->join('items', 'items.id', 'carts.item_id')
        ->join('stores', 'items.store_id', 'stores.id')
        ->where('carts.user_id', $user_id)->where('carts.is_guest',$is_guest)->where('carts.module_id',5)
        ->select('items.name', 'items.image', 'items.price as item_price', 'items.discount as item_discount', 'items.discount_type','stores.slug as store_slug', 'carts.*')
        ->get();

       return view('front-views.cart', compact('cart'));
    }
    public function checkout()
    {
        $user_id = auth('web')->user() ? auth('web')->user()->id : session()->get('guest_id') ;
        $is_guest = auth('web')->user() ? 0 : 1;

        $cart = DB::table('carts')
        ->join('items', 'items.id', 'carts.item_id')
        ->join('stores', 'stores.id', 'items.store_id')
        ->where('carts.user_id', $user_id)->where('carts.is_guest',$is_guest)->where('carts.module_id',5)
        ->select('items.name', 'items.image', 'items.price as item_price', 'items.discount as item_discount', 'items.discount_type', 'items.store_id', 'carts.*')
        ->get();

        $store = Store::where('id', $cart[0]->store_id )->first(); 
        // prx($store);
       return view('front-views.checkout', compact('cart', 'store'));
    } 

    public function store_details(Request $request, $slug){
        $longitude = $this->longitude;
        $latitude = $this->latitude;
        $store = StoreLogic::get_store_details($slug,$longitude,$latitude);
        if($store)
        {
            $category_ids = DB::table('items')
            ->join('categories', 'items.category_id', '=', 'categories.id')
            ->selectRaw('categories.position as positions, IF((categories.position = "0"), categories.id, categories.parent_id) as categories')
            ->where('items.store_id', $store->id)
            ->where('categories.status',1)
            ->groupBy('categories','positions')  
            ->get();

            $store = Helpers::store_data_formatting($store);
            $store['category_ids'] = array_map('intval', $category_ids->pluck('categories')->toArray());
            $store['category_details'] = Category::whereIn('id',$store['category_ids'])->get();
            $store['price_range']  = Item::withoutGlobalScopes()->where('store_id', $store->id)
            ->select(DB::raw('MIN(price) AS min_price, MAX(price) AS max_price'))
            ->get(['min_price','max_price']);


            //products 
            $limit=25;
            $offset=1;
    
            $type = $request->query('type', 'all');
    
            $paginator = Item::with('tags')->type($type)->Approved()->where('store_id', $store->id)->latest()->paginate($limit, ['*'], 'page', $offset);

            // prx( $paginator); 
            $productdata = [
                'total_size' => $paginator->total(),
                'limit' => $limit,
                'offset' => $offset,
                'items' => Helpers::product_data_formatting($paginator->items(), true, true, app()->getLocale())
            ];

            // prx($productdata); 
            
             
        }

        return view('front-views.store_details', compact('store', 'productdata'));

    }

    public function product_details(Request $request, $slug){
        // echo 'fd'; 
        // prx(config('module.current_module_data'));        // product details 
        $item = DB::table('items')
        ->join('categories', 'items.category_id', 'categories.id')
        ->join('stores', 'stores.id', 'items.store_id') 
        ->where('items.slug', $slug)
        ->select('items.*', 'categories.name as category_name', 'categories.slug as category_slug', 'stores.name as store_name', 'stores.slug as store_slug')
        ->first();  
        // prx($item);      
        
        // all categories 
        $catController = new V1CategoryController();
        $resp = $catController->get_categories($request);
        $data['categories'] = json_decode($resp->getContent(), true);
        foreach ($data['categories'] as $key => $value) {
            $data['categories'][$key]['product_count'] = Item::where('category_id', $value['id'])->count() ;
          }
        // prx($data['categories'] );

        $data['featured_products'] = DB::table('items')
        ->join('categories', 'items.category_id' ,'categories.id')
        ->where(['categories.featured' => 1, 'categories.status' => 1, 'categories.position'=> 0, 'items.status' => 1])
        ->select('items.*')
        ->limit(5)
        ->get();

        // $data['related products'] = 
        // prx($data['featured_products'][0]->name);   

        return view('front-views.product_details', compact('item', 'data'));
    }

    public function category_listing(Request $request, $slug){
        $catDetails = Category::where('slug', $slug)->first();
        $catProducts  = Item::where('category_id', $catDetails->id)->where('status', 1)->paginate(6);

          // all categories 
          $catController = new V1CategoryController();
          $resp = $catController->get_categories($request);
          $data['all_categories'] = json_decode($resp->getContent(), true);
          foreach ($data['all_categories'] as $key => $value) {
            $data['all_categories'][$key]['product_count'] = Item::where('category_id', $value['id'])->count() ;
          }

          $data['featured_products'] = DB::table('items')
          ->join('categories', 'items.category_id' ,'categories.id')
          ->where(['categories.featured' => 1, 'categories.status' => 1, 'categories.position'=> 0, 'items.status' => 1])
          ->select('items.*')
          ->limit(5)
          ->get();

        //   prx( $data['all_categories']); 
        
        return view('front-views.category_listing', compact('catDetails', 'catProducts', 'data'));
    }
}